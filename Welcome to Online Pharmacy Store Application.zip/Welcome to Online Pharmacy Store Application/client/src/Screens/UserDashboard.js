import React from 'react';
import Base from '../Components/Base';
import { useDispatch, useSelector } from 'react-redux';


const UserDashboard = () => {
  const data = useSelector((state) => state.auth)
  return (
    <Base title='👤User Dashboard👤'>
      <div className='bg-cyan-200 shadow-md rounded-xl px-8 pt-6 pb-8 m-10  flex flex-col font-bold'>
       User Id:- {data.user._id}<br/>
       User Name:- {data.user.username}<br/>
       User Type:- {data.user.customerType}


      </div>
    </Base>
  );
};
export default UserDashboard;
