import React from 'react';
import { Slide } from 'react-slideshow-image';
import './Slide.css';
import 'react-slideshow-image/dist/styles.css'
const slideImages = [
  'https://thumbor.forbes.com/thumbor/960x0/https%3A%2F%2Fspecials-images.forbesimg.com%2Fimageserve%2F5e86c57510005200067deb53%2FHealthcare-and-medical-concept--Medicine-doctor-with-stethoscope-in-hand-and-Patients%2F960x0.jpg%3Ffit%3Dscale',
  'https://image.shutterstock.com/image-vector/various-meds-pills-capsules-blisters-260nw-1409823341.jpg',
  'https://www.srisriholistichospitals.com/wp-content/uploads/2020/04/How-Online-Pharmacy-Can-Keep-You-Healthy-During-a-Lockdown-Period.jpg',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSimFm0NCOX-TZ00RFRN1gXwR3TZWRkCI9N5Q&usqp=CAU'
];

const Slideshow = () => {
    return (
      <div>
        <Slide easing="ease">
          <div className="each-slide ">
            <div style={{'backgroundImage': `url(${slideImages[0]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[1]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[2]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[3]})`}}>
            </div>
          </div>
        </Slide>
      </div>
    )
};

export default Slideshow;