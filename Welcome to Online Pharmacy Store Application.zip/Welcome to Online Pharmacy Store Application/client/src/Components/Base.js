import React from 'react';
import Header from './Header';
import SearchBar from './SearchBar';
import { useLocation } from 'react-router-dom';
import Slide from './Slide';

const Base = ({ title, children }) => {
  const flage = useLocation().pathname === '/';

  return (
    <div className='flex flex-col min-h-screen'>
       <marquee direction="left" size="+2" className="bg-red-100 py-2 px-2 font-bold">Hello User Welcome to Online Pharmacy Store🏥
        Here you can find All types of medicines and devices also💊💊💉💉 Helpdesk Contact Center's toll free number is +1-866-832-3090.</marquee>
      <SearchBar />
      <Header />
      <Slide />
      {flage ? (
        <>

        </>
      ) : null}

      <div className='flex items-center justify-center m-8'>
        <h1 className='text-3xl font-extrabold'>{title}</h1>
      </div>
      <main className='flex-grow'>{children}</main>
      <footer className='flex items-center justify-center bg-pink-800 p-6'>
        <span className='text-sm text-white font-bold '>
          © {new Date().getFullYear()}, Developed by
          <a> Anshuman Das</a>
        </span>
      </footer>
    </div>
  );
};

export default Base;
