import React from 'react';

const SearchBar = () => (
	<div className="flex items-center justify-between p-3">
		<div className="flex items-center flex-wrap">
			<h1 className="text-4xl font-extrabold text-yellow-200 text-center text-style-bold ">
         🚑🚑 Pharmacy Online 🚑🚑
			</h1>
		</div>

		<input
			className="w-full p-2 border-4 border-blue-900 rounded-l-xl focus:outline-pink focus:border-yellow-500"
			type="text"
			placeholder="Search Here......"
		/>
		{/* search button */}
		<button className="bg-yellow-400  py-3 px-6 rounded-r-xl ">
			<svg
				className="w-6 h-6"
				fill="none"
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth="4"
				viewBox="0 0 24 24"
				stroke="currentColor">
				<path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
			</svg>
		</button>
	</div>
);

export default SearchBar;
